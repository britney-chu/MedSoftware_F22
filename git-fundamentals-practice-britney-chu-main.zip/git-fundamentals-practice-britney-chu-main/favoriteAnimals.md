# Ranked List of Britney Chu's Favorite Animals
	1. Capybara
	2. Otter
	3. Dolfin
	4. Tree Kangaroo
	5. Goat

## Why Capybaras?
It is clear to see from this list that I love mammals. There are many animals I love that are not mammals but they unfortunatly do not make the top 5.

At the top of this list is the beautiful and magnificent capybara. This animal is one of the most expressive animals I have seen. I truly believe that they experience
complex human emotions such as jealousy, greif, regret, and disdain. This is very interesting to me and I love to observe them. I sometimes fear when animals have the
ability to experience these emotions, as in the case of chimpanzees. However, capybaras do not have the physical adaptations necessary to act upon these emotions in an
effective way. I also find that their shape is very fun. It looks like a really big guinea pig.
